# React Quiz App 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Joel-Musonda/pen/OJqRqmo](https://codepen.io/Joel-Musonda/pen/OJqRqmo).

