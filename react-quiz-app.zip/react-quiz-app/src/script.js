function App() {
  const Questions = [
     {
      questionText: "Which git command is used to get a repository",
      answerOptions: [
        { answerText: "Commit", isCorrect: false },
        { answerText: "Clone", isCorrect: true },
        { answerText: "Pull", isCorrect: false},
      ]
    },
    
    {
      questionText : "Which programming language was named after an indonesian coffe? ",
      answerOptions : [
        {answerText : "Javascript " , isCorrect : false},
        {answerText : "Java" , isCorrect : true},
        {answerText : "C++" , isCorrect : false},
      ]
    },
    {
      questionText:"Among the following which is the most used Javacript Framework",
      answerOptions : [
        {answerText:"React" , isCorrect : true},
        {answerText : "Vue" , isCorrect : false},
        {answerText: 'Angular' , isCorrect : false},
      ]
    }
  ]
  
  
    const [currentQuestion , setCurrentQuestion] = React.useState(0);
  const [showScore , setShowScore] = React.useState(false);
  const[score , setScore] = React.useState(0);
  
 const handleAnswerButtonClick = (isCorrect) =>{
   if(isCorrect === true){
     setScore(score + 1)
   }
   const nextQuestion = currentQuestion + 1;
   if(nextQuestion < Questions.length){
       setCurrentQuestion(nextQuestion)
   }else{
setShowScore(true)
   }
   
 }
  
  const title = "React Simple Quiz App";
  
  

  
  return(
    <div>
  <h3>{title}</h3>
  <div className = "app">
      {showScore ? (
      <div>
          you scored {score} out of {Questions.length}
          </div>
      ):(
      <>    
          <div className = "question-section">
            <div className = "question-count">
              <span>Question {currentQuestion + 1}/</span>{Questions.length}
            </div>
            <div className="question-text"> 
              {Questions[currentQuestion].questionText}
            </div>
          </div>
          <div className="answer-section">
              {Questions[currentQuestion].answerOptions.map((answerOptions)=>(
           <button onClick = {()=> handleAnswerButtonClick(answerOptions.isCorrect)}>
             {answerOptions.answerText}
           </button>
            ))}
    
        
        </div>
          
         
          </>
      )}
    
    </div> 
    </div>
        
  );
}







const element = document.getElementById("root");
const root = ReactDOM.createRoot(element);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
